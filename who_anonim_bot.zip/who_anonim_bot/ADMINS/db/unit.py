"""
db package initializer
"""

from .database import db