import os
from dotenv import load_dotenv

# Загружаем переменные из .env файла
load_dotenv()

# ============================================================
# 🔐 TOKEN
# ============================================================

TOKEN = os.getenv("BOT_TOKEN", "8134649307:AAH3k13igSnG9t6lGYYTvu7e2D4RiKaCXMI")

if not TOKEN:
    raise ValueError(
        "❌ Ошибка: BOT_TOKEN не найден. "
        "Добавьте BOT_TOKEN в .env файл."
    )


# ============================================================
# 👑 АДМИНЫ (список)
# ============================================================

admins_raw = os.getenv("ADMINS", "7967404620")

if admins_raw.strip():
    ADMIN_IDS = [int(x) for x in admins_raw.replace(" ", "").split(",")]
else:
    ADMIN_IDS = []


# ============================================================
# ⚙ Параметры проекта
# ============================================================

PROJECT_NAME = "Who?Anonim™"
ANON_PREFIX = "Anon"          # имя для анонимов: Anon #1234
LINK_ID_LENGTH = 6            # длина ID ссылки (например 483920)

MAX_BROADCAST_LENGTH = 4000   # максимум символов рассылки
MAX_SESSIONS_PER_OWNER = 500  # макс. активных анонимов за владельцем

# База данных
DATABASE_PATH = "bot/db/storage.db"